#!/bin/bash

if [[ $1 == 1 ]];then
    sudo apt update && apt upgrade -y
    sudo apt install bc
    # Restart Kali Linux
    sudo apt-get install build-essential
    sudo apt-get install libelf-dev
    sudo apt-get install linux-headers-`uname -r`
    #important
    sudo apt install dkms
    sudo rmmod r8188eu.ko
    unzip rtl8188eus-5.3.9.zip
    cd rtl8188eus-5.3.9
    sudo -i
    echo "blacklist r8188eu" > "/etc/modprobe.d/realtek.conf"
    # Important before make and make install
    echo "Reboot"
    exit
elif [[ $1 == 2 ]];then
    sudo apt update
    cd rtl8188eus-5.3.9
    sudo make && make install
    sudo modprobe 8188eu
fi

echo "To test:
airmon-ng check kill
ifconfig wlan0 down
iw dev wlan0 set type monitor
ifconfig wlan0 up

TEST- sudo aireplay-ng --test wlan0"